﻿IATI Xml File Pager
-------------------
When runned, the iati-xmlpager will download the newest version of the IATI activities file and split it into a number of XML-files, each containing IATI activities.

Usage
-----
    .\iati-xmlpager

Configuration file
------------------
    .\iati-xmlpager.exe.config